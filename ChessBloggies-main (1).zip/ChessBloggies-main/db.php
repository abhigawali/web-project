<?php
   $db= mysqli_connect('localhost','root','','chessblog') or die("Database is not connected");
?>