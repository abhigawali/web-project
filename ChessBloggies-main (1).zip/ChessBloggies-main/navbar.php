<nav class = "navbar">
        <div class = "container">
          <a href = "index.php" class = "navbar-brand" id="top">CHESS BLOGGIES</a>
          <div class = "navbar-nav">
            <a href = "index.php">home</a>
            <a href = "index.php#topics">topics</a>
            <a href = "index.php#blogs">blogs</a>
            <a href = "index.php#about">about</a>
            <a href = "Admin_panel\login.php">Login</a>
          </div>
        </div>
</nav>