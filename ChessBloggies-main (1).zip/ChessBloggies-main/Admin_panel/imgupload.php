<?php
    error_reporting(0);
    function imgupload(){
        
    }
?>
