<div class = "banner">
        <div class = "container">
          <h1 class = "banner-title" >
            <span></span>Chess Bloggies
          </h1>
          <p>Everything that you want to know about chess</p>
          <form action="searchresult.php">
            <input type = "text" class = "search-input" name ="search"  placeholder="find your blog . . .">
            <button type = "submit" class = "search-btn">
              <i class = "fas fa-search"></i>
            </button>
          </form>
        </div>
      </div>